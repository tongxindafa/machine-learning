# Machine-Learning-homework
Matlab coding homework for Machine Learning in Coursera by Andrew Ng.

For those seeking the answer of quizzes, I have some links that show most of the answers in Chinese. Here I show great thanks to the authors who writing those solutions:

https://www.cnblogs.com/maxiaodoubao/p/10184428.html

https://www.cnblogs.com/xingkongyihao/category/1161554.html

If the owners of the two blogs deem it offensive, please contact me and I will remove the links immediately!
